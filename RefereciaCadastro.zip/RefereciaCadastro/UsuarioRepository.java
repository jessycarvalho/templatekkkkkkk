package candy.shop.repository;

import org.springframework.data.repository.CrudRepository;

import candy.shop.model.Usuario;

public interface UsuarioRepository extends CrudRepository<Usuario, String> {
	Usuario findByLogin(String login);
}
