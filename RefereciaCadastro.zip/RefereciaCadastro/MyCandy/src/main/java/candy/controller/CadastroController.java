package candy.controller;


import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import candy.model.Usuario;
import candy.repository.UsuarioRepository;



@Controller
public class CadastroController {
	
	@Autowired
	private UsuarioRepository ur;
	
	@RequestMapping(value="/cadastro", method=RequestMethod.GET)
	public String logar(){
		//System.out.println(getUsuarioLogado());	
		return "cadastro";
	}
	
	
	@RequestMapping(value="/cadlogin", method = RequestMethod.POST)
	public String cadlogin(@RequestParam String login,
			               @RequestParam String nome, 
						   @RequestParam String password,						   
    					   Usuario usuario,			                   
                           HttpSession session) {	 
		
		
		
	 usuario.setLogin(login);
	 usuario.setNomeCompleto(nome);
	 usuario.setSenha(password); //sem criptografia
		 
	 ur.save(usuario);
		
		
	 return "login";	  
	  
	}
	
	
	
	


}

