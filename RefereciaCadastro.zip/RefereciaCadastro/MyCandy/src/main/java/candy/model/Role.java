package candy.model;

public class Role {

}
