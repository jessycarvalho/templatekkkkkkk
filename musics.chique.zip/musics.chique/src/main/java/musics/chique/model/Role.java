package musics.chique.model;

public class Role {

}
